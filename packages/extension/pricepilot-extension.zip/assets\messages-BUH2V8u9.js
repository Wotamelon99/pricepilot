function t(e){return typeof e=="object"&&e!==null&&e.type==="pricepilot:search"}function r(e){return typeof e=="object"&&e!==null&&e.type==="pricepilot:get-settings"}function n(e){return typeof e=="object"&&e!==null&&e.type==="pricepilot:get-current-product"}export{r as a,n as b,t as i};
//# sourceMappingURL=messages-BUH2V8u9.js.map
