function f(t){return t.toLowerCase().replace(/^www\./,"").replace(/[^a-z0-9]/g,"")}function a(t,n){let e;try{e=new URL(n).hostname}catch{return!1}const r=f(e),o=f(t);return o.length>0&&r.includes(o)}function c(t,n){return t.map(e=>({...e,offers:e.offers.filter(r=>!a(r.merchantName,n))})).filter(e=>e.offers.length>0)}export{c as e};
//# sourceMappingURL=current-site-offer-PcQ8hCtO.js.map
